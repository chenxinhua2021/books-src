/*
 * add.h
 *
 *  Created on: 2013/06/23
 *      Author: shanai
 */

#ifndef ADD_H_
#define ADD_H_

int calc(int i1, int i2);

#endif /* ADD_H_ */
