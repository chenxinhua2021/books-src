/*
 * add.c
 *
 *  Created on: 2013/06/23
 *      Author: shanai
 */

#include "add.h"

int add(int i1, int i2) {
    return i1 + i2;
}

