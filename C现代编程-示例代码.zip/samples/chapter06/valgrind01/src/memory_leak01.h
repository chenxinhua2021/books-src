#ifndef _MEMORY_LEAK01_H_
#define _MEMORY_LEAK01_H_

#ifdef __cplusplus
extern "C" {
#endif

void memoryLeak();

#ifdef __cplusplus
}
#endif

#endif
