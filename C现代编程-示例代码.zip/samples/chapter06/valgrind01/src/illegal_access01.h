#ifndef _ILLEGAL_READ01_H_
#define _ILLEGAL_READ01_H_

#ifdef __cplusplus
extern "C" {
#endif

int illegalRead(int *p);
void illegalWrite(int *p);

#ifdef __cplusplus
}
#endif

#endif
