#ifndef _STRCPY01_H_
#define _STRCPY01_H_

#ifdef __cplusplus
extern "C" {
#endif

char *dropTop(char *p);

#ifdef __cplusplus
}
#endif

#endif
