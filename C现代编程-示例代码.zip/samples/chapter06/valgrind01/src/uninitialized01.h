#ifndef _UNINITILIZED01_H_
#define _UNINITILIZED01_H_

#ifdef __cplusplus
extern "C" {
#endif

void uninitialized();

#ifdef __cplusplus
}
#endif

#endif
