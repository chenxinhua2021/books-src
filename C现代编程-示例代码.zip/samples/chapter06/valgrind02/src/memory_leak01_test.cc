#include "gtest/gtest.h"
#include "memory_leak01.h"

TEST(MemoryLeakTest01, memoryLeak01) {
    memoryLeak();
}
