#include "gtest/gtest.h"
#include "uninitialized01.h"

TEST(UninitializedTest01, uninitialized01) {
    uninitialized();
}
