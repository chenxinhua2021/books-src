/*
 * add.h
 *
 *  Created on: 2013/06/23
 *      Author: shanai
 */

#ifndef ADD_H_
#define ADD_H_

#ifdef __cplusplus
extern "C" {
#endif

int add(int i1, int i2);

#ifdef __cplusplus
}
#endif


#endif /* ADD_H_ */
