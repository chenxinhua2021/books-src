#ifndef _COMMON_H_
#define _COMMON_H_

#ifndef __18CXX
#define rom
#endif

#endif
