#ifndef _STACK_H_
#define _STACK_H_

#ifdef __cplusplus
extern "C" {
#endif

bool push(int val);
bool pop(int *pRet);

#ifdef __cplusplus
}
#endif

#endif
