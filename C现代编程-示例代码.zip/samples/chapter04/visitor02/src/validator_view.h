#ifndef _VALIDATOR_VIEW_H_
#define _VALIDATOR_VIEW_H_

#ifdef __cplusplus
extern "C" {
#endif

void printValidator(const Validator *p, char *pBuf, size_t size);

#ifdef __cplusplus
}
#endif

#endif
