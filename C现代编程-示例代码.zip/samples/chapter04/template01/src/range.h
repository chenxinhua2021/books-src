#ifndef _COUNTER_H_
#define _COUNTER_H_

#ifdef __cplusplus
extern "C" {
#endif

int range(const char *pFname);

#ifdef __cplusplus
}
#endif

#endif

