#ifndef _RANGE_H_
#define _RANGE_H_

#ifdef __cplusplus
extern "C" {
#endif

int range(const char *pFname);

#ifdef __cplusplus
}
#endif

#endif

