/*
 * kernel.h
 *
 *  Created on: Sep 7, 2013
 *      Author: ggew
 */

#ifndef KERNEL_H_
#define KERNEL_H_

//extern "C"
void hostFE (double uX, double uY, double lX, double lY, QImage * im, int resX, int resY);

#endif /* KERNEL_H_ */
