The source code in this directory requires the use of a Compute Capability 3.0 or above device.

After compilation, run the program by passing as a command-line parameter the filename of a PGM image. Example:

	./histogram mountains.pgm

