To run the program, setup the parameters in a text file, e.g. spec.in and invoke it as follows:
./mandelHybrid spec.in 7 1 

where 7 is the total number of threads to use (CPU and GPU combined) and 1 to indicate that a GPU will be used.